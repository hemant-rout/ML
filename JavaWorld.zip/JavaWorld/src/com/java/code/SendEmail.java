package com.java.code;

import java.io.IOException;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendEmail {

	private static void send_notification(Session session,String fromEmail,String toEmail,String message) {
		
		MimeMessage msg = new MimeMessage(session);
		
		try {
			msg.setFrom(new InternetAddress(fromEmail));
			msg.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));
			msg.setSubject("ExpenseManager Notification");
			
			Multipart emailContent = new MimeMultipart();
			MimeBodyPart textBodyPart = new MimeBodyPart();
			textBodyPart.setText(message);
			emailContent.addBodyPart(textBodyPart);
			msg.setContent(emailContent);
			Transport.send(msg);
			System.out.println("Sent message");
		} catch (MessagingException e) {
			e.printStackTrace();
		}

	}

	
	private static String parseLog(String logFilePath) {
		// TODO Auto-generated method stub
		String message="My multipart text";
		return message;
	}
	
	public static void main(String[] args) throws IOException {

//		Properties properties = new Properties();
//		properties.put("mail.smtp.auth", "true");
//		properties.put("mail.smtp.starttls.enable", "true");
//		properties.put("mail.smtp.host", "smtp.office365.com");
//		properties.put("mail.smtp.port", "587");
		
//		Session session = Session.getInstance(properties, new javax.mail.Authenticator() {
//			protected PasswordAuthentication getPasswordAuthentication() {
//				return new PasswordAuthentication(Props.username,Props.password);
//			}
//		});
		
		String message=SendEmail.parseLog("");
		Session session=NotificationSession.getInstance().getSession();
		send_notification(session,Props.fromEmail,Props.toEmail,message);
	}
}
