package com.java.code;

public class Props {

	final static String username = "xyz@abc.com";
	final static String password = "test";
	final static String fromEmail = "hemantkumarrout@outlook.com";
	final static String toEmail = "hemantkumarrout@gmail.com";

}
