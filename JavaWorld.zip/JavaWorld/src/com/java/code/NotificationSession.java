package com.java.code;

import java.util.Properties;

import javax.mail.PasswordAuthentication;
import javax.mail.Session;



public class NotificationSession {

    private static NotificationSession instance;
    private static Session session ;


    private NotificationSession() {
      // private constructor //
    }

    public static NotificationSession getInstance(){
    if(instance==null){
        instance= new NotificationSession();
    }
    return instance;
    }

    public Session getSession(){

        if(session==null){
            
            	Properties properties = new Properties();
        		properties.put("mail.smtp.auth", "true");
        		properties.put("mail.smtp.starttls.enable", "true");
        		properties.put("mail.smtp.host", "smtp.office365.com");
        		properties.put("mail.smtp.port", "587");
        		
                session = Session.getInstance(properties, new javax.mail.Authenticator() {
        			protected PasswordAuthentication getPasswordAuthentication() {
        				return new PasswordAuthentication(Props.username,Props.password);
        			}
        		});
            
        }

        return session;
    }
}